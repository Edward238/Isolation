#pragma once

#define RFU_VERSION "1.2.1"
#define RFU_GITHUB_REPO "Edward238/Isolation"

bool CheckForUpdates();
void SetFPSCapExternal(double value);
